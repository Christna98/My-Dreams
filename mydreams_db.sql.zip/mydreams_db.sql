-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 23 fév. 2022 à 08:36
-- Version du serveur : 10.4.22-MariaDB
-- Version de PHP : 8.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `mydreams_db`
--
CREATE DATABASE IF NOT EXISTS `mydreams_db` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `mydreams_db`;

-- --------------------------------------------------------

--
-- Structure de la table `entreprises`
--
-- Création : mer. 23 fév. 2022 à 05:07
-- Dernière modification : mer. 23 fév. 2022 à 07:12
--

DROP TABLE IF EXISTS `entreprises`;
CREATE TABLE IF NOT EXISTS `entreprises` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idGroupe` int(11) NOT NULL,
  `nomEntreprise` varchar(255) NOT NULL,
  `nomProprietaire` varchar(255) NOT NULL,
  `prenomProprietaire` varchar(255) NOT NULL,
  `sexe` char(1) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `typePieceProprietaire` varchar(255) NOT NULL,
  `noPieceProprietaire` int(11) NOT NULL,
  `dateCreation` datetime NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- RELATIONS POUR LA TABLE `entreprises`:
--

-- --------------------------------------------------------

--
-- Structure de la table `prets`
--
-- Création : mer. 23 fév. 2022 à 05:18
-- Dernière modification : mer. 23 fév. 2022 à 05:13
--

DROP TABLE IF EXISTS `prets`;
CREATE TABLE IF NOT EXISTS `prets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idGroupe` int(11) NOT NULL,
  `montantEmprunte` float NOT NULL,
  `interet` float NOT NULL,
  `versementMensuel` float NOT NULL,
  `datePret` date NOT NULL,
  `dateVersement1` date NOT NULL,
  `dateVersement2` date NOT NULL,
  `dateVersement3` date NOT NULL,
  `dateVersement4` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- RELATIONS POUR LA TABLE `prets`:
--

-- --------------------------------------------------------

--
-- Structure de la table `remboursements`
--
-- Création : mar. 22 fév. 2022 à 05:04
--

DROP TABLE IF EXISTS `remboursements`;
CREATE TABLE IF NOT EXISTS `remboursements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idPret` int(11) NOT NULL,
  `nomVersememt` varchar(255) NOT NULL,
  `montantRembourser` float NOT NULL,
  `dateRemboursement` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_prets_remboursements` (`idPret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- RELATIONS POUR LA TABLE `remboursements`:
--   `idPret`
--       `prets` -> `id`
--

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `remboursements`
--
ALTER TABLE `remboursements`
  ADD CONSTRAINT `fk_prets_remboursements` FOREIGN KEY (`idPret`) REFERENCES `prets` (`id`);


--
-- Métadonnées
--
USE `phpmyadmin`;

--
-- Métadonnées pour la table entreprises
--

--
-- Métadonnées pour la table prets
--

--
-- Métadonnées pour la table remboursements
--

--
-- Métadonnées pour la base de données mydreams_db
--
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
